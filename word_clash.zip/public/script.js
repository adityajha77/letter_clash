let currentWord = ""; // Word currently in play
let lastLetter = "";  // Last letter of the current word
let usedWords = new Set(); // To track all used words
let score = 0; // Player's score
let timer; // Timer reference
let timeLeft = 45; // Timer countdown in seconds

const randomWordContainer = document.getElementById("random-word");
const lastLetterContainer = document.getElementById("last-letter");
const inputBox = document.getElementById("input-box");
const submitButton = document.getElementById("submit-btn");
const startButton = document.getElementById("start-btn");
const timerContainer = document.getElementById("timer");
const scoreContainer = document.getElementById("score");

async function fetchRandomWord(letter = null) {
    try {
        const apiUrl = letter
            ? `https://api.datamuse.com/words?sp=${letter}*&max=1000`
            : `https://api.datamuse.com/words?sp=?????&max=1000`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Filter to exclude already used words
        const validWords = data.filter(wordObj => !usedWords.has(wordObj.word));
        if (validWords.length === 0) {
            alert("No valid words available. Game over!");
            resetGame();
            return null;
        }

        const randomIndex = Math.floor(Math.random() * validWords.length);
        return validWords[randomIndex].word;
    } catch (error) {
        console.error("Error fetching word:", error);
        return null;
    }
}

function startTimer() {
    timeLeft = 45;
    timerContainer.textContent = timeLeft;

    timer = setInterval(() => {
        timeLeft -= 1;
        timerContainer.textContent = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timer);
            alert("Time's up! Computer wins.");
            resetGame();
        }
    }, 1000);
}

async function startGame() {
    startButton.disabled = true;
    inputBox.value = "";
    score = 0;
    scoreContainer.textContent = score;
    usedWords.clear();

    currentWord = await fetchRandomWord();
    if (!currentWord) return; // Handle if no word is fetched

    usedWords.add(currentWord);
    updateDisplay(currentWord);
    startTimer();
}

function updateDisplay(word) {
    randomWordContainer.textContent = word;
    lastLetter = word[word.length - 1].toLowerCase();
    lastLetterContainer.textContent = `Your next word must start with "${lastLetter.toUpperCase()}"`;
}

async function handlePlayerInput() {
    const playerWord = inputBox.value.trim().toLowerCase();
    inputBox.value = "";

    // Validate player's word
    if (!playerWord || usedWords.has(playerWord)) {
        alert("Word already used or invalid. Try again!");
        return;
    }
    if (playerWord[0] !== lastLetter) {
        alert(`Your word must start with "${lastLetter.toUpperCase()}".`);
        return;
    }

    // Player's word is valid
    usedWords.add(playerWord);
    score += 1;
    scoreContainer.textContent = score;
    clearInterval(timer); // Reset the timer
    startTimer();

    // Fetch computer's response
    const computerWord = await fetchRandomWord(playerWord[playerWord.length - 1]);
    if (!computerWord) return; // Handle if no valid word is fetched

    usedWords.add(computerWord);
    updateDisplay(computerWord);
}

function resetGame() {
    clearInterval(timer);
    currentWord = "";
    lastLetter = "";
    usedWords.clear();
    score = 0;
    scoreContainer.textContent = score;
    randomWordContainer.textContent = "Press 'Start' to Begin";
    lastLetterContainer.textContent = "";
    startButton.disabled = false;
}

startButton.addEventListener("click", startGame);
submitButton.addEventListener("click", handlePlayerInput);

const gradients = [
    "linear-gradient(to right, #ff7e5f, #feb47b)", // Warm gradient
    "linear-gradient(to right, #6a11cb, #2575fc)", // Purple-blue gradient
    "linear-gradient(to right, #ff9a9e, #fad0c4)", // Soft pink gradient
    "linear-gradient(to right, #a18cd1, #fbc2eb)", // Lavender-pink gradient
    "linear-gradient(to right, #43cea2, #185a9d)", // Aqua-blue gradient
    "linear-gradient(to right, #de6262, #ffb88c)", // Sunset gradient
    "linear-gradient(to right, #02aab0, #00cdac)", // Teal-green gradient
    "linear-gradient(to right, #ff9966, #ff5e62)", // Orange-red gradient
];

let currentGradientIndex = 0;

function changeBackground() {
    currentGradientIndex = (currentGradientIndex + 1) % gradients.length; // Cycle through gradients
    document.body.style.background = gradients[currentGradientIndex];
}

async function handlePlayerInput() {
    const playerWord = inputBox.value.trim().toLowerCase();
    inputBox.value = "";

    // Validate player's word
    if (!playerWord || usedWords.has(playerWord)) {
        alert("Word already used or invalid. Try again!");
        return;
    }
    if (playerWord[0] !== lastLetter) {
        alert(`Your word must start with "${lastLetter.toUpperCase()}".`);
        return;
    }

    // Player's word is valid
    usedWords.add(playerWord);
    score += 1;
    scoreContainer.textContent = score;

    // Change background on every multiple of 5
    if (score % 5 === 0) {
        changeBackground();
    }

    clearInterval(timer); // Reset the timer
    startTimer();

    // Fetch computer's response
    const computerWord = await fetchRandomWord(playerWord[playerWord.length - 1]);
    if (!computerWord) return; // Handle if no valid word is fetched

    usedWords.add(computerWord);
    updateDisplay(computerWord);
}
