const express = require('express');
const path = require('path');
const axios = require('axios');

const app = express();
const PORT = 3000;

// Middleware to serve static files
app.use(express.static(path.join(__dirname, '../public')));

// Route to serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// API to fetch a random word
app.get('/random-word', async (req, res) => {
    try {
        const apiUrl = 'https://api.datamuse.com/words?sp=?????&max=1000';
        const response = await axios.get(apiUrl);

        const randomIndex = Math.floor(Math.random() * response.data.length);
        const word = response.data[randomIndex]?.word;

        if (!word) throw new Error('No valid word fetched');

        res.json({ word });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Failed to fetch random word' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
